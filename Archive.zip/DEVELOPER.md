# Developer Guide

This document is for maintainers and contributors working on `tauri-plugin-scoped-storage`.

## Goals

- Provide stable, user-approved folder access for Tauri 2 mobile apps.
- Keep the Rust command layer as the canonical validation boundary.
- Return predictable error payloads to guest JavaScript.
- Favor conservative behavior over permissive behavior for filesystem mutations.

## Repository Layout

- `src/`
  Rust plugin entry point, shared models, path policy, desktop fallback, and mobile bridge.
- `guest-js/`
  TypeScript guest API source. This is the authoritative JS-facing API.
- `dist-js/`
  Built guest bindings published to npm consumers.
- `android/src/main/java/`
  Android implementation using the Storage Access Framework and persisted tree URI permissions.
- `ios/Sources/`
  iOS implementation using document pickers, bookmarks, and security-scoped resource access.
- `permissions/`
  Tauri permission manifests generated for the command surface.
- `examples/tauri-app/`
  Demo app used for manual validation and smoke testing.
- `docs/`
  Extra notes, including manual test coverage.

## Architecture

The plugin has three main layers:

1. Rust command boundary
   `src/commands.rs` validates folder IDs and paths, normalizes request payloads, and rejects invalid operations before native code runs.
2. Native platform implementation
   `src/mobile.rs` forwards validated commands to Android or iOS, where platform-specific filesystem work happens.
3. Guest bindings
   `guest-js/index.ts` exposes a typed JS API and performs lightweight argument checks for early developer feedback.

Desktop targets intentionally return `UNSUPPORTED` so consumers can handle the platform gap explicitly.

## Safety Rules

These rules are intentional and should be preserved unless the public contract is being changed deliberately:

- Paths must stay relative to the user-selected folder.
- `..`, absolute paths, drive-style prefixes, and URI-like prefixes are rejected.
- Empty paths are rejected for destructive and file-specific operations.
- Blank optional directory paths are treated as the folder root.
- Blank folder IDs are rejected at the Rust boundary.
- `copy`, `move`, and `rename` reject identical source and destination values.
- Errors should map to stable codes from `src/error.rs`.

If a platform change requires looser behavior, update the Rust validation, guest API expectations, tests, and README together.

## Error Contract

The JS side should receive a serializable payload with:

- `code`
- `message`

Current stable codes are defined in `src/error.rs`. Native code should continue emitting the structured `SCOPED_STORAGE_ERROR:<CODE>:<message>` format whenever possible so Rust can normalize failures consistently.

## Build And Test

From the repository root:

```sh
cargo fmt
cargo test
yarn build
yarn --cwd examples/tauri-app build
```

What these cover:

- `cargo test`
  Rust unit tests for path normalization, model serialization, and command-boundary validation.
- `yarn build`
  Rebuilds `dist-js/` from `guest-js/index.ts`.
- `yarn --cwd examples/tauri-app build`
  Verifies the demo app still compiles against the local package.

## When Changing The API

If you add, remove, or rename a command:

1. Update `src/lib.rs` and `src/commands.rs`.
2. Update shared models in `src/models.rs` if request or response payloads changed.
3. Update Android and iOS implementations to keep feature parity.
4. Update `guest-js/index.ts`.
5. Rebuild `dist-js/` with `yarn build`.
6. Regenerate or review permission manifests in `permissions/` if needed.
7. Update `README.md` and manual test notes.

Do not ship a command on only one mobile platform unless the asymmetry is clearly documented and intentional.

## Release Hygiene

Before publishing or tagging a release:

- Run the full build and test commands above.
- Check that generated `dist-js/` files match the current `guest-js/` source.
- Confirm there are no placeholder names, sample-only strings, or debug artifacts in tracked files.
- Verify README setup snippets still match the published API.
- Verify license metadata stays aligned across `Cargo.toml`, `package.json`, and `LICENSE`.

## Manual Testing

Use the example app for mobile verification. At minimum, test:

- folder pick and restore
- read directory at root and nested paths
- text read/write/append
- binary read/write
- mkdir and remove
- copy/move/rename
- truncate grow and shrink
- cancellation and permission-denied flows

More detailed notes belong in `docs/manual-test-notes.md`.

## Editing Expectations

- Treat `guest-js/` as source and `dist-js/` as generated output.
- Keep the Rust layer strict and predictable.
- Prefer additive tests when tightening validation.
- Avoid platform-specific behavior drift unless documented and justified.
