# Tauri Plugin Scoped Storage

`tauri-plugin-scoped-storage` is a mobile-first Tauri 2 plugin for working inside user-approved folders on Android and iOS.

It is intentionally different from `@tauri-apps/plugin-fs`:

- `@tauri-apps/plugin-fs` focuses on app-known paths and base-directory scoping.
- `tauri-plugin-scoped-storage` focuses on folders the user explicitly picks at runtime.
- Android uses the Storage Access Framework with persisted tree URI permissions.
- iOS uses `UIDocumentPickerViewController` with persisted bookmark restoration.

The plugin keeps a Rust-first public contract, exposes guest JS bindings, and delegates platform filesystem behavior to native Android and iOS code.

License: MIT. Contributor-facing implementation notes live in [DEVELOPER.md](/Users/danielerolli/tauri-plugin-scoped-storage/DEVELOPER.md).

## Supported Platforms

- Android
- iOS
- Desktop targets currently return stable `UNSUPPORTED` errors

## Feature Surface

Folder and session management:

- `pickFolder`
- `forgetFolder`
- `listFolders`
- `getFolderInfo`

Directory operations:

- `readDir`
- `mkdir`
- `removeDir`
- `exists`
- `stat`

File operations:

- `readFile`
- `writeFile`
- `readTextFile`
- `writeTextFile`
- `readTextFileLines`
- `appendFile`
- `removeFile`
- `copy`
- `move`
- `rename`
- `truncate`

## Intentionally Unsupported

These are not implemented yet and should be treated as unsupported for now:

- `open`
- `create`
- persistent file handles and handle-based `read` / `write` / `append` / `close`
- `watch` and `watchImmediate`
- `lstat`

## Path Safety

Every Rust command that accepts a path runs `normalize_relative_path` before calling native code.

Current policy:

- backslashes are normalized to `/`
- empty segments and `.` are collapsed
- `..` is rejected
- absolute paths are rejected
- URI-style and drive-style prefixes are rejected
- destructive commands require a non-empty relative path

The native Android and iOS layers also validate path components defensively, but Rust owns the primary policy.

Additional boundary validation:

- blank optional directory paths are normalized to the folder root
- blank folder IDs are rejected before native code runs
- copy, move, and rename reject identical source and destination paths

## Error Model

Native failures are normalized into stable Rust/JS error payloads:

- `UNSUPPORTED`
- `INVALID_PATH`
- `FOLDER_NOT_FOUND`
- `NOT_FOUND`
- `ALREADY_EXISTS`
- `PERMISSION_DENIED`
- `CANCELLED`
- `IO_ERROR`
- `NATIVE_ERROR`
- `INVALID_ARGUMENT`

## Permissions

Grant the plugin capability in your app capability file:

```json
{
  "permissions": [
    "core:default",
    "scoped-storage:default"
  ]
}
```

The default permission set lives in [permissions/default.toml](/Users/danielerolli/tauri-plugin-scoped-storage/permissions/default.toml).

## Setup

Rust:

```rust
fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_scoped_storage::init())
        .run(tauri::generate_context!())
        .expect("failed to run tauri application");
}
```

JavaScript:

```ts
import {
  appendTextFile,
  pickFolder,
  readDir,
  readTextFile,
  writeTextFile,
} from "tauri-plugin-scoped-storage-api";

const folder = await pickFolder();
await writeTextFile(folder.id, "notes/hello.txt", "Hello from scoped storage", true);
await appendTextFile(folder.id, "notes/hello.txt", "\nMore text", {
  recursive: true,
  create: true,
});
const text = await readTextFile(folder.id, "notes/hello.txt");
const entries = await readDir(folder.id, "notes");
```

## Platform Notes

Android:

- The plugin stores opaque folder IDs in app storage and maps them to persisted SAF tree URIs.
- File and directory work is performed through `DocumentFile` and `ContentResolver`.
- `truncate` uses a writable file descriptor and zero-fills when growing a file.
- Cross-parent moves fall back to copy-then-delete when SAF rename semantics are insufficient.

iOS:

- The plugin stores opaque folder IDs and restores bookmarks on later app launches.
- Security-scoped access is opened only for the duration of each command.
- Stale bookmarks are refreshed when iOS reports them as stale.
- Writes, appends, and truncation use coordinated access around the target file URL.

## Example App

The example app in [examples/tauri-app](/Users/danielerolli/tauri-plugin-scoped-storage/examples/tauri-app) exercises:

- folder picking and persisted handle listing
- directory reads
- text and binary read/write
- append
- mkdir
- remove file / remove dir
- copy / move / rename
- truncate
- structured error logging

## Manual Test Notes

Focused manual test coverage notes live in [manual-test-notes.md](/Users/danielerolli/tauri-plugin-scoped-storage/docs/manual-test-notes.md).
